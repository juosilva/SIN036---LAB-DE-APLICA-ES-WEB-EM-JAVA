
package DAO;

import DAO.ConnectionFactory;
import model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ProdutoDAO {
    private Connection conn;
    private PreparedStatement stmt;
    private Statement st;
    private ResultSet rs;
    private ArrayList<Produto> lista = new ArrayList<>();
    

    public ProdutoDAO() {
        conn = new ConnectionFactory().getConxao();
    }
    
    public void inserir(Produto produto){
        String sql = "INSERT INTO produto(descricao, preco) VALUES (?, ?)";
        try{   
         stmt = conn.prepareStatement(sql);
         stmt.setString(1, produto.getDescricao());
         stmt.setFloat(2, produto.getPreco());
         stmt.execute();
         stmt.close();
        }catch(Exception erro){
            throw new RuntimeException("Erro ao Inserir: "+erro);
        }
    }
    
    public void alterar(Produto produto){
        String sql = "UPDATE produto SET descricao = ?, preco=? WHERE codigo =?";
        try{
         stmt = conn.prepareStatement(sql);
         stmt.setString(1, produto.getDescricao());
         stmt.setFloat(2, produto.getPreco());
         stmt.setInt(3, produto.getCodigo());
         stmt.execute();
         stmt.close();
        }catch(Exception erro){
            throw new RuntimeException("Erro ao Alterar: "+erro);
        }
    }
    
    
    public void excluir(int codigo){
        String sql = "DELETE FROM produto WHERE codigo = "+codigo;
        try{   
            st = conn.createStatement();
            st.execute(sql);
            st.close();
            
        }catch(Exception erro){
            throw new RuntimeException("Erro ao Excluir ProdDAO: "+erro);
        }
    }
    
    public ArrayList<Produto> listarTodos(){
         String sql = "SELECT * FROM Produto";
         try{   
            st = conn.createStatement();
            rs =  st.executeQuery(sql);
            while(rs.next()){
                Produto produto = new Produto();
                produto.setCodigo(rs.getInt("codigo"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setPreco(rs.getFloat("preco"));
                lista.add(produto);
            }
            
        }catch(Exception erro){
            throw new RuntimeException("Erro ao Listar: "+erro);
        }
         return lista;
    }
    
    
    public ArrayList<Produto> listarPorDescricao(String descricao){
         String sql = "SELECT * FROM Produto WHERE descricao like '%"+descricao+"%'";
         try{   
            st = conn.createStatement();
            rs =  st.executeQuery(sql);
            while(rs.next()){
                Produto produto = new Produto();
                produto.setCodigo(rs.getInt("codigo"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setPreco(rs.getFloat("preco"));
                lista.add(produto);
            }
            
        }catch(Exception erro){
            throw new RuntimeException("Erro ao Listar por descrição: "+erro);
        }
         return lista;
    }
    
    
    
   
    
}
