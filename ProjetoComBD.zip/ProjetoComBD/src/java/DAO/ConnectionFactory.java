package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 
public class ConnectionFactory {
    
    public Connection getConxao(){
        try {
            //System.out.println("Teste!");
            //Class.forName("com.mysql.cj.jdbc.Driver");
            //System.out.println("Teste!");
            /*DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            return DriverManager.getConnection(
            "jdbc:mysql://localhost/produto?useTimezone=true&serverTimezone=UTC", "root", "");
            */
            
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            return DriverManager.getConnection(
            "jdbc:mysql://localhost/produto?useTimezone=true&serverTimezone=UTC", "root", "");
            
            
            
        }catch (SQLException erro) {
            throw new RuntimeException("Erro na conexao **********: " +erro);
        }
    }

}
